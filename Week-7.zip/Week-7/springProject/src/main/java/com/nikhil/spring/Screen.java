package com.nikhil.spring;

public class Screen {
	
	private int length;
	private int breadth;
	
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getBreadth() {
		return breadth;
	}
	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
	
	public void showScreen() {
		System.out.println("Screen is shown");
	}


}
