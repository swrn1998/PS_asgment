package com.nikhil.spring;

public class Camera {
	
	private double megaPixels;

	public double getMegaPixels() {
		return megaPixels;
	}

	public void setMegaPixels(double megaPixels) {
		this.megaPixels = megaPixels;
	}
	
	public void showCamera() {
		System.out.println("Camera generated");
	}
	
	

}
