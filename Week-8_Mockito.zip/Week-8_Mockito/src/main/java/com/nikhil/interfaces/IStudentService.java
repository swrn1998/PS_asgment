package com.nikhil.interfaces;

import com.nikhil.exceptions.NameNotValidException;
import com.nikhil.model.Student;

public interface IStudentService {
	public Student insertStudent(Student student) throws NameNotValidException;

}
