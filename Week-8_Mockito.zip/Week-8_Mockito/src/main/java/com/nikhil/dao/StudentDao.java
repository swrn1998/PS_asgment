package com.nikhil.dao;

import com.nikhil.model.Student;

public class StudentDao {
	
	public static void insertStudentToDB(Student student) {
		System.out.println(student + " added");
	}

}
