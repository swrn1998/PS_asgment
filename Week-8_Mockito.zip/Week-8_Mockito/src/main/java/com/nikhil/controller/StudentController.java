package com.nikhil.controller;

import com.nikhil.exceptions.NameNotValidException;
import com.nikhil.model.Student;
import com.nikhil.service.StudentService;

public class StudentController {
	
	StudentService service;
	
	public Student insertStudent(Student student) throws NameNotValidException {
		service = new StudentService();
		return service.insertStudent(student);
	}

}
