package com.nikhil.exceptions;

public class NameNotValidException extends Exception {
	public NameNotValidException(String s) {
		
	}
}
