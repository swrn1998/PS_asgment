package com.nikhil.tests;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.nikhil.exceptions.NameNotValidException;
import com.nikhil.model.Student;
import com.nikhil.service.StudentService;

@RunWith(MockitoJUnitRunner.class)
public class StudentTest {

	Student student = mock(Student.class);
	StudentService service = mock(StudentService.class);
	
	@Before
	public void setUp() throws Exception {
		student = new Student(1, "John Doe");
	}

	@Test
	public void test() throws NameNotValidException {
		when(service.insertStudent(student)).thenReturn(student);
	}

}
